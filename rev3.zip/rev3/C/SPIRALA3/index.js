const express = require("express");
const app = express();
const bodyParser = require('body-parser');
const fs = require("fs");
var path = require("path");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static("public"));

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/pocetna.html'))
});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/sale.html'))
});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/unos.html'))
});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/rezervacija.html'))
});

app.get('/ucitaj', function (req, res) {
    fs.readFile('zauzeca.json', (err, data) => {
        if (err) throw err;
        res.send(data)
    });
})

app.post('/upisiVanrednoZauzece', function (req, res) {
    fs.readFile('zauzeca.json', (err, data) => {
        if (err) throw err;

        let tijelo = req.body;
        let van1 = {
            "datum": tijelo["datum"],
            "pocetak": tijelo["pocetak"],
            "kraj": tijelo["kraj"],
            "naziv": tijelo["naziv"],
            "predavac": tijelo["predavac"]
        };

        let zauzeca = JSON.parse(data);

        let vanOdper = PretvoriUVanredna(zauzeca.periodicna); //niz vanrednih zauzeca koja su periodicna

        let razlicita1;
        let razlicita2;

        for (let i = 0; i < zauzeca.vanredna.length; i++) {
            razlicita1 = true;
            if (zauzeca.vanredna[i].datum === van1.datum &&
                zauzeca.vanredna[i].naziv === van1.naziv &&
                ((USekunde(van1.pocetak) >= USekunde(zauzeca.vanredna[i].pocetak) &&
                    USekunde(van1.pocetak) < USekunde(zauzeca.vanredna[i].kraj)) ||
                    (USekunde(van1.kraj) > USekunde(zauzeca.vanredna[i].pocetak) &&
                        USekunde(van1.kraj) <= USekunde(zauzeca.vanredna[i].kraj)) ||
                    (USekunde(van1.pocetak) < USekunde(zauzeca.vanredna[i].pocetak) &&
                        USekunde(van1.kraj) > USekunde(zauzeca.vanredna[i].kraj)))
            ) {
                razlicita1 = false;
                break;
            }
        }

        for (let i = 0; i < vanOdper.length; i++) {
            razlicita2 = true;
            if (vanOdper[i].datum === van1.datum &&
                vanOdper[i].naziv === van1.naziv &&
                ((USekunde(van1.pocetak) >= USekunde(vanOdper[i].pocetak) &&
                    USekunde(van1.pocetak) < USekunde(vanOdper[i].kraj)) ||
                    (USekunde(van1.kraj) > USekunde(vanOdper[i].pocetak) &&
                        USekunde(van1.kraj) <= USekunde(vanOdper[i].kraj)) ||
                    (USekunde(van1.pocetak) < USekunde(vanOdper[i].pocetak) &&
                        USekunde(van1.kraj) > USekunde(vanOdper[i].kraj)))
            ) {
                razlicita2 = false;
                break;
            }
        }

        if (razlicita1 && razlicita2) {
            zauzeca.vanredna.push(van1);
            fs.writeFile('zauzeca.json', JSON.stringify(zauzeca), 'utf-8', function (err) {
                if (err) throw err
                res.setHeader('Content-Type', 'application/json');
                res.send(JSON.stringify(zauzeca));
            });
        }
        else {
            let dat = van1.datum.replace(/[.]/g, "/");
            res.setHeader('Content-Type', 'text/plain');
            res.send("Nije moguće rezervisati salu " + van1.naziv + " za navedeni datum " + dat + " i termin od " + van1.pocetak + " do " + van1.kraj + "!");
        }
    });
})


app.post('/upisiPeriodicnoZauzece', function (req, res) {
    fs.readFile('zauzeca.json', (err, data) => {
        if (err) throw err;

        let tijelo = req.body;
        let per1 = {
            "dan": tijelo["dan"],
            "semestar": tijelo["semestar"],
            "pocetak": tijelo["pocetak"],
            "kraj": tijelo["kraj"],
            "naziv": tijelo["naziv"],
            "predavac": tijelo["predavac"]
        };

        let per1Arr = new Array();
        per1Arr.push(per1);

        let zauzeca = JSON.parse(data);

        let vanOdper = PretvoriUVanredna(zauzeca.periodicna); //niz vanrednih zauzeca koja su periodicna
        let vanOdper1 = PretvoriUVanredna(per1Arr);


        let razlicita1;
        let razlicita2;
        for (let j = 0; j < vanOdper1.length; j++) {
            razlicita1 = true;
            for (let i = 0; i < zauzeca.vanredna.length; i++) {
                if (zauzeca.vanredna[i].datum === vanOdper1[j].datum &&
                    zauzeca.vanredna[i].naziv === vanOdper1[j].naziv &&
                    ((USekunde(vanOdper1[j].pocetak) >= USekunde(zauzeca.vanredna[i].pocetak) &&
                        USekunde(vanOdper1[j].pocetak) < USekunde(zauzeca.vanredna[i].kraj)) ||
                        (USekunde(vanOdper1[j].kraj) > USekunde(zauzeca.vanredna[i].pocetak) &&
                            USekunde(vanOdper1[j].kraj) <= USekunde(zauzeca.vanredna[i].kraj)) ||
                        (USekunde(vanOdper1[j].pocetak) < USekunde(zauzeca.vanredna[i].pocetak) &&
                            USekunde(vanOdper1[j].kraj) > USekunde(zauzeca.vanredna[i].kraj)))
                ) {
                    razlicita1 = false;
                    break;
                }
            }
            if (razlicita1 === false) {
                break;
            }
        }
        for (let j = 0; j < vanOdper1.length; j++) {
            razlicita2 = true;
            for (let i = 0; i < vanOdper.length; i++) {
                if (vanOdper[i].datum === vanOdper1[j].datum &&
                    vanOdper[i].naziv === vanOdper1[j].naziv &&
                    ((USekunde(vanOdper1[j].pocetak) >= USekunde(vanOdper[i].pocetak) &&
                        USekunde(vanOdper1[j].pocetak) < USekunde(vanOdper[i].kraj)) ||
                        (USekunde(vanOdper1[j].kraj) > USekunde(vanOdper[i].pocetak) &&
                            USekunde(vanOdper1[j].kraj) <= USekunde(vanOdper[i].kraj)) ||
                        (USekunde(vanOdper1[j].pocetak) < USekunde(vanOdper[i].pocetak) &&
                            USekunde(vanOdper1[j].kraj) > USekunde(vanOdper[i].kraj)))
                ) {
                    razlicita2 = false;
                    break;
                }
            }
            if (razlicita2 === false) {
                break;
            }
        }

        if (razlicita1 && razlicita2) {
            zauzeca.periodicna.push(per1);

            fs.writeFile('zauzeca.json', JSON.stringify(zauzeca), 'utf-8', function (err) {
                if (err) throw err
                res.setHeader('Content-Type', 'application/json');
                res.send(JSON.stringify(zauzeca));
            });
        }
        else {
            let dat = tijelo["datum"].replace(/[.]/g, "/");
            let mm = tijelo["datum"].substring(3, 5);
            if (mm === "07" || mm === "08" || mm === "09") {
                let mj = "";
                if (mm === "07") mj = "Julu";
                else if (mm === "08") mj = "Augustu";
                else if (mm === "09") mj = "Septembru";
                res.setHeader('Content-Type', 'text/plain');
                res.send("Greška! Nije moguće rezervisati periodično zauzeće u mjesecu " + mj + "!");
            } else {
                res.setHeader('Content-Type', 'text/plain');
                res.send("Nije moguće rezervisati salu " + per1.naziv + " za navedeni datum " + dat + " i termin od " + per1.pocetak + " do " + per1.kraj + "!");
            }
        }
    });
})


app.get('/oznaciSlike', function (req, res) {
    fs.readFile('slike.json', (err, data) => {
        if (err) throw err;
        let slike = JSON.parse(data);
        for (let i = 0; i < slike.length; i++) slike[i].ucitana = "false";
        fs.writeFile('slike.json', JSON.stringify(slike), 'utf-8', function (err) {
            if (err) throw err
        });
    });
})

app.get('/slike', function (req, res) {
    fs.readFile('slike.json', (err, data) => {
        if (err) throw err;
        let slike = JSON.parse(data);
        let ucSlike = new Array();
        for (let i = 0; i < slike.length; i++) {
            if (slike[i].ucitana === "false") {
                let slika = new Object();
                slika.id = (i + 1).toString();
                slika.src = slike[i].src;
                ucSlike.push(slika);
                slike[i].ucitana = "true";
            }
            if (ucSlike.length === 3) break;
        }
        fs.writeFile('slike.json', JSON.stringify(slike), 'utf-8', function (err) {
            if (err) throw err
            res.send(JSON.stringify(ucSlike));
        });
    });
})

app.listen(8080);



function vanrednoP(datum, pocetak, kraj, naziv, predavac) {
    let van = new Object();
    let dd = datum.getDate().toString();
    let mm = (datum.getMonth() + 1).toString();
    let yyyy = datum.getFullYear().toString();
    if (dd < 10 && dd.length === 1) dd = "0" + dd;
    if (mm < 10 && mm.length === 1) mm = "0" + mm;
    van.datum = dd + "." + mm + "." + yyyy;
    van.pocetak = pocetak;
    van.kraj = kraj;
    van.naziv = naziv;
    van.predavac = predavac;
    return van;
}


function PretvoriUVanredna(periodicna) {
    let vanOdPer = new Array();
    let trenutniDatum = new Date();
    let trenutnaGodina = trenutniDatum.getFullYear();
    //za svako periodicno zauzece
    for (let i = 0; i < periodicna.length; i++) {

        let per = periodicna[i];

        //semestar zimski (jan, okt, nov, dec)
        if (per.semestar === "zimski") {

            let prviJanuar = new Date(trenutnaGodina, 0, 1);
            let zadnjiJanuar = new Date(trenutnaGodina, 1, 0);
            let prviOktobar = new Date(trenutnaGodina, 9, 1);
            let zadnjiOktobar = new Date(trenutnaGodina, 10, 0);
            let prviNovembar = new Date(trenutnaGodina, 10, 1);
            let zadnjiNovembar = new Date(trenutnaGodina, 11, 0);
            let prviDecembar = new Date(trenutnaGodina, 11, 1);
            let zadnjiDecembar = new Date(trenutnaGodina, 12, 0);


            //za januar
            for (let i = prviJanuar.getDate(); i <= zadnjiJanuar.getDate(); i++) {
                if (prviJanuar.getDay().toString() === per.dan) {
                    let dat = new Date(prviJanuar);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviJanuar.setDate(prviJanuar.getDate() + 1);
            }

            //za oktobar
            for (let i = prviOktobar.getDate(); i <= zadnjiOktobar.getDate(); i++) {
                if (prviOktobar.getDay().toString() === per.dan) {
                    let dat = new Date(prviOktobar);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviOktobar.setDate(prviOktobar.getDate() + 1);
            }

            //za novembar
            for (let i = prviNovembar.getDate(); i <= zadnjiNovembar.getDate(); i++) {
                if (prviNovembar.getDay().toString() === per.dan) {
                    let dat = new Date(prviNovembar);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviNovembar.setDate(prviNovembar.getDate() + 1);
            }

            //za decembar
            for (let i = prviDecembar.getDate(); i <= zadnjiDecembar.getDate(); i++) {
                if (prviDecembar.getDay().toString() === per.dan) {
                    let dat = new Date(prviDecembar);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviDecembar.setDate(prviDecembar.getDate() + 1);
            }
        }
        else if (per.semestar === "ljetni") {
            let prviFebruar = new Date(trenutnaGodina, 1, 1);
            let zadnjiFebruar = new Date(trenutnaGodina, 2, 0);
            let prviMart = new Date(trenutnaGodina, 2, 1);
            let zadnjiMart = new Date(trenutnaGodina, 3, 0);
            let prviApril = new Date(trenutnaGodina, 3, 1);
            let zadnjiApril = new Date(trenutnaGodina, 4, 0);
            let prviMaj = new Date(trenutnaGodina, 4, 1);
            let zadnjiMaj = new Date(trenutnaGodina, 5, 0);
            let prviJuni = new Date(trenutnaGodina, 5, 1);
            let zadnjiJuni = new Date(trenutnaGodina, 6, 0);

            //za februar
            for (let i = prviFebruar.getDate(); i <= zadnjiFebruar.getDate(); i++) {
                if (prviFebruar.getDay().toString() === per.dan) {
                    let dat = new Date(prviFebruar);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviFebruar.setDate(prviFebruar.getDate() + 1);
            }

            //za mart
            for (let i = prviMart.getDate(); i <= zadnjiMart.getDate(); i++) {
                if (prviMart.getDay().toString() === per.dan) {
                    let dat = new Date(prviMart);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviMart.setDate(prviMart.getDate() + 1);
            }

            //za april
            for (let i = prviApril.getDate(); i <= zadnjiApril.getDate(); i++) {
                if (prviApril.getDay().toString() === per.dan) {
                    let dat = new Date(prviApril);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviApril.setDate(prviApril.getDate() + 1);
            }

            //za maj
            for (let i = prviMaj.getDate(); i <= zadnjiMaj.getDate(); i++) {
                if (prviMaj.getDay().toString() === per.dan) {
                    let dat = new Date(prviMaj);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviMaj.setDate(prviMaj.getDate() + 1);
            }

            //za juni
            for (let i = prviJuni.getDate(); i <= zadnjiJuni.getDate(); i++) {
                if (prviJuni.getDay().toString() === per.dan) {
                    let dat = new Date(prviJuni);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviJuni.setDate(prviJuni.getDate() + 1);
            }
        }
    }
    return vanOdPer;
}


function USekunde(vrijeme) {
    let a = vrijeme.split(":");
    let seconds = a[0] * 60 * 60 + a[1] * 60;
    return seconds;
}
