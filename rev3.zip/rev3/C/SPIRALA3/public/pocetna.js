var ucitaneSlike = new Array();
var ucitanesveSlike;

function UpisiUcitaneSlike(slikeSrc) {
    for (let i = 0; i < slikeSrc.length; i++)
        ucitaneSlike.push(slikeSrc[i].src);
}

function postaviUcitaneSveSlike(vrijednost) {
    ucitanesveSlike = vrijednost;
}

//vraca id posljednje prve slike 
function dajPosljednjuPrvuSliku() {
    let l = ucitaneSlike.length;
    let rez = "";
    if (l % 3 != 0) rez += "slika" + (l - l % 3 - 2).toString();
    else if (l % 3 === 0 && l > 3) rez += "slika" + (l - 5);
    return rez;
}

window.onload = function () {
    Pozivi.oznaciNeucitane(); //prilikom ucitavanja stranice, svaki put se osigurava da su sve slike neucitane, odnosno ispravno ucitavanje prvih slike
    document.getElementById("prethodni").disabled = true;
    document.getElementById("sljedeci").disabled = false;
    Pozivi.ucitajSlike(); //ucitavaju se prve 0-3 slike
};

function Sljedeci() {
    document.getElementById("prethodni").disabled = false;
    if (ucitanesveSlike && document.getElementById("s0").getElementsByTagName("img")[0].id === dajPosljednjuPrvuSliku())
        document.getElementById("sljedeci").disabled = true;

    let prvaSlika = document.getElementById("s0").getElementsByTagName("img")[0];

    //ako nisu ucitane sve slike i trenutno su prikazane posljednje ucitane, ucitaj nove slike
    if (!ucitanesveSlike && (prvaSlika.src === 'http://localhost:8080/' + ucitaneSlike[ucitaneSlike.length - 3])) {
        Pozivi.ucitajSlike();
    }
    else {
        for (let i = 0; i < ucitaneSlike.length; i++) {
            if (prvaSlika.src === 'http://localhost:8080/' + ucitaneSlike[i]) {
                let br = i;
                for (let j = 0; j < 3; j++) {
                    if (ucitaneSlike.length >= (br + 4)) {
                        document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].id = "slika" + (br + 4).toString();
                        document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].alt = "slika" + (br + 4).toString();
                        document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].src = 'http://localhost:8080/' + ucitaneSlike[br + 3];
                    }
                    else {
                        document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].id = "slika" + (br + 4).toString();
                        document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].alt = "slika" + (br + 4).toString();
                        document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].style.display = "none";
                    }
                    br++;
                }
                return;
            }
        }
    }
}


function Prethodni() {
    document.getElementById("sljedeci").disabled = false;
    let prvaSlika = document.getElementById("s0").getElementsByTagName("img")[0];
    if (prvaSlika.id === "slika4") document.getElementById("prethodni").disabled = true
    if (ucitanesveSlike && document.getElementById("s0").getElementsByTagName("img")[0].id === dajPosljednjuPrvuSliku() && ucitaneSlike.length === 3)
        document.getElementById("sljedeci").disabled = true;

    for (let i = 0; i < ucitaneSlike.length; i++) {
        if (prvaSlika.src === 'http://localhost:8080/' + ucitaneSlike[i]) {
            let br = i;
            for (let j = 0; j < 3; j++) {
                if (br >= 3) {
                    if (document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].style.display === "none")
                        document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].style.display = "block";

                    document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].id = "slika" + (br - 2).toString();
                    document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].alt = "slika" + (br - 2).toString();
                    document.getElementById("s" + j.toString()).getElementsByTagName("img")[0].src = 'http://localhost:8080/' + ucitaneSlike[br - 3];
                }
                br++;
            }
            return;
        }
    }
}