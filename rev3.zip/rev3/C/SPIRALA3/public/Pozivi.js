let Pozivi = (function () {
    function ucitajPodatkeSaServeraImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                var zauzeca = JSON.parse(ajax.responseText);
                Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", "ucitaj", true);
        ajax.send();
    }

    function upisiVanrednoZauzeceImpl(datum, pocetak, kraj, naziv, predavac) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                var contentType = ajax.getResponseHeader("Content-Type");

                if (contentType === "text/plain; charset=utf-8") {
                    var tekst = ajax.responseText;
                    zatvoriConfirm();
                    otvoriConfirm(tekst, "confirm/error.png", "", "OK");
                }
                else if (contentType === "application/json; charset=utf-8") {
                    var zauzeca = JSON.parse(ajax.responseText);
                    Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
                    Kalendar.SalaOboji();
                    zatvoriConfirm();
                    otvoriConfirm("Uspješno rezervisan termin!", "confirm/success.png", "", "OK");
                }
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("POST", "upisiVanrednoZauzece", true);
        ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        ajax.send("datum=" + datum + "&pocetak=" + pocetak + "&kraj=" + kraj + "&naziv=" + naziv + "&predavac=" + predavac);
    }

    function upisiPeriodicnoZauzeceImpl(dan, semestar, pocetak, kraj, naziv, predavac, datum) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                var contentType = ajax.getResponseHeader("Content-Type");

                if (contentType === "text/plain; charset=utf-8") {
                    var tekst = ajax.responseText;
                    zatvoriConfirm();
                    otvoriConfirm(tekst, "confirm/error.png", "", "OK");
                }
                else if (contentType === "application/json; charset=utf-8") {
                    var zauzeca = JSON.parse(ajax.responseText);
                    Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
                    Kalendar.SalaOboji();
                    zatvoriConfirm();
                    otvoriConfirm("Uspješno rezervisan termin!", "confirm/success.png", "", "OK");
                }
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("POST", "upisiPeriodicnoZauzece", true);
        ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        ajax.send("dan=" + dan + "&semestar=" + semestar + "&pocetak=" + pocetak + "&kraj=" + kraj + "&naziv=" + naziv + "&predavac=" + predavac + "&datum=" + datum);
    }

    function ucitajSlikeImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                let slike = JSON.parse(ajax.responseText);
                if (slike.length != 0) {
                    if (slike.length < 3) {
                        postaviUcitaneSveSlike(true);
                        document.getElementById("sljedeci").disabled = true;
                        if (ucitaneSlike.length <= 3) document.getElementById("prethodni").disabled = true;
                    }
                    else {
                        postaviUcitaneSveSlike(false);
                    }
                    //prve tri slike
                    if (ucitaneSlike.length === 0) {
                        for (let i = 0; i < slike.length; i++) {
                            let s = new Image();
                            s.id = "slika" + slike[i].id;
                            s.alt = "slika" + slike[i].id;
                            s.src = slike[i].src;
                            s.classList.add("galerija");
                            document.getElementById("s" + i.toString()).appendChild(s);
                        }
                        UpisiUcitaneSlike(slike);
                    }
                    else {
                        for (let i = 0; i < slike.length; i++) {
                            let s = document.getElementById("s" + i.toString()).getElementsByTagName("img")[0];
                            s.id = "slika" + slike[i].id;
                            s.alt = "slika" + slike[i].id;
                            s.src = slike[i].src;
                        }
                        for (let i = slike.length; i < 3; i++) {
                            document.getElementById("s" + i.toString()).getElementsByTagName("img")[0].style.display = "none";
                        }
                        UpisiUcitaneSlike(slike);
                    }
                }
                else {
                    postaviUcitaneSveSlike(true);
                    if (ucitaneSlike.length % 3 === 0) {
                        document.getElementById("sljedeci").disabled = true;
                        if (ucitanesveSlike && ucitaneSlike.length != 0 && document.getElementById("s0").getElementsByTagName("img")[0].id === "slika1")
                            document.getElementById("prethodni").disabled = true;

                    }
                }
            }

            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", 'slike', true);
        ajax.send();
    }


    function oznaciNeucitaneImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
            }

            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", '/oznaciSlike', true);
        ajax.send();
    }
    return {
        ucitajPodatkeSaServera: ucitajPodatkeSaServeraImpl,
        upisiVanrednoZauzece: upisiVanrednoZauzeceImpl,
        upisiPeriodicnoZauzece: upisiPeriodicnoZauzeceImpl,
        ucitajSlike: ucitajSlikeImpl,
        oznaciNeucitane: oznaciNeucitaneImpl
    };
})();

