

let Pozivi = (function(){
    //
    //ovdje idu privatni atributi
    var poziv_iz_drugog=false;

    function per(dan,semestar,pocetak,kraj,naziv,predavac){
        this.dan=dan;
        this.semestar=semestar;
        this.pocetak=pocetak;
        this.kraj=kraj;
        this.naziv=naziv;
        this.predavac=predavac;
    }
    
    function van(datum,pocetak,kraj,naziv,predavac){
        this.datum=datum;
        this.pocetak=pocetak;
        this.kraj=kraj;
        this.naziv=naziv;
        this.predavac=predavac;
    }

    var niz_slika=[];
    var br_poziva_slj=0;
    var br_poziva_pret=0;
    var br_slika;
    var br_sl_uk=0;

    window.onload=function(){
        Pozivi.prvi();
    }

    function ucitavanjeUKalendar(podatci){
        var per_niz=[];
        var van_niz=[];
        var podatci_per=podatci.periodicna;
        var podatci_van=podatci.vandredna;

        for(var i=0;i<podatci_per.length;i++){
            var dann=podatci_per[i].dan;
            var ii=new per(parseInt(dann),podatci_per[i].semestar,podatci_per[i].pocetak,podatci_per[i].kraj,podatci_per[i].naziv,podatci_per[i].predavac);
        
            per_niz.push(ii);
        }

        for(var j=0;j<podatci_van.length;j++){
            var jj=new van(podatci_van[j].datum,podatci_van[j].pocetak,podatci_van[j].kraj,podatci_van[j].naziv,podatci_van[j].predavac);
            van_niz.push(jj);
        }
        Kalendar.ucitajPodatke(podatci_per,podatci_van);
    }

    //
    function prviImpl(){
    //implementacija ide ovdje
    
    var ajax = new XMLHttpRequest();
    ajax.open("GET","http://localhost:8080/ucitaj",true);
    //ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
    ajax.onreadystatechange = function(){
        if(ajax.readyState==4 && ajax.status==200){
            var podatci = JSON.parse(ajax.responseText);
            ucitavanjeUKalendar(podatci);
        }
    }
    
    
    }
    function drugiImpl(dat){
    //implementacija ide ovdje
    var sale=document.getElementById("sala");
    var odabSala = sale.options[sale.selectedIndex].value;
    var poc = document.getElementById("pocetak");
    var kraj = document.getElementById("kraj");
    var per = document.getElementById("periodicna").checked;

    var date=new Date();
    var firstDay =  new Date(date.getFullYear(), Kalendar.tr_mjesec, 1);
    var s=firstDay.getDay();
    var dd;
    if(s===0){
        s=6;
        dd=(s-1)+parseInt(dat);
    }else{
        dd=(s-2)+parseInt(dat);
    }
    
    dd=dd%7;
    
    

    

    var ajax = new XMLHttpRequest();
    if(per===true){
        ajax.open("POST","http://localhost:8080/upisiper?dan="+dd+"&sala="+odabSala+"&pocetak="+poc.value+"&kraj="+kraj.value+"&mjesec="+Kalendar.tr_mjesec+"&datum="+dat,true);
    }
    else{
        ajax.open("POST","http://localhost:8080/upisivan?datum="+dat+"&sala="+odabSala+"&pocetak="+poc.value+"&kraj="+kraj.value+"&mjesec="+Kalendar.tr_mjesec,true);
    }
    
    
    ajax.send();
    ajax.onreadystatechange = function(){
        if(ajax.readyState==4 && ajax.status==200){
            

            var podatci = JSON.parse(ajax.responseText);
            if(podatci.mesage){
                alert(podatci.mesage);
            }
            else{
                ucitavanjeUKalendar(podatci);
            }
            Kalendar.obojiZauzeca(document.getElementById("kalendar"),Kalendar.tr_mjesec,Kalendar.ssala,Kalendar.ppoc,Kalendar.pkraj);

        }
        
    }
    }
    function treciImpl(){
    //implementacija ide ovdje


    if(br_poziva_slj==0){
        br_poziva_pret++;
            br_poziva_slj++;
            var ajax = new XMLHttpRequest();
            ajax.open("GET","http://localhost:8080/ucitajsl?br="+br_poziva_slj,true);    
            ajax.send();
            ajax.onreadystatechange = function(){
                if(ajax.readyState==4 && ajax.status==200){
                    var podatci=JSON.parse(ajax.responseText);
                    br_slika=Object.keys(podatci).length;
                    br_sl_uk+=br_slika;
                    for(var i=0;i<3;i++){
                        let slika=document.createElement("img");
                        slika.className="kolona jedan";
                        slika.alt="slika";
                        if(i==0){
                            slika.src=podatci.slika1;
                            niz_slika.push(podatci.slika1);
                        }
                        else if(i==1){
                            slika.src=podatci.slika2;
                            niz_slika.push(podatci.slika2);
                        }
                        else{
                            slika.src=podatci.slika3;
                            niz_slika.push(podatci.slika3);
                        }
                        document.getElementsByClassName("red")[0].appendChild(slika);
                    }
        
                }
            }
    }





    
    var prr=document.getElementById("prethodni");

if(prr){
    prr.addEventListener("click", function(){
        if(br_poziva_pret>1){
            br_poziva_pret--;
            for(var i=0;i<3;i++){
                if(i==0){
                    document.getElementsByClassName("kolona jedan")[i].src=niz_slika[(br_poziva_pret-1)*3+i];
                }
                else if(i==1){
                    if((br_poziva_pret-1)*3+i<br_sl_uk){
                        document.getElementsByClassName("kolona jedan")[i].style.visibility='visible';
                        document.getElementsByClassName("kolona jedan")[i].src=niz_slika[(br_poziva_pret-1)*3+i];
                    }
                    
                }
                else{
                    if((br_poziva_pret-1)*3+i<br_sl_uk){
                        document.getElementsByClassName("kolona jedan")[i].style.visibility='visible';
                        document.getElementsByClassName("kolona jedan")[i].src=niz_slika[(br_poziva_pret-1)*3+i];
                    }
                }
            }
        }
    });
}    

var sljj=document.getElementById("sljedeci");
if(sljj){
    sljj.addEventListener("click", function(){
        var slj=true;
        if(br_slika==3){
            
        
            if(br_poziva_pret==br_poziva_slj){
                br_poziva_pret++;
                br_poziva_slj++;
                var ajax = new XMLHttpRequest();
                ajax.open("GET","http://localhost:8080/ucitajsl?br="+br_poziva_slj,true);    
                ajax.send();
                ajax.onreadystatechange = function(){
                    if(ajax.readyState==4 && ajax.status==200){
                        var podatci=JSON.parse(ajax.responseText);

                        br_slika=Object.keys(podatci).length;
                        br_sl_uk+=br_slika;
                        if(podatci.length!=3){slj==false;}
                        for(var i=0;i<3;i++){
                            if(i==0){
                                document.getElementsByClassName("kolona jedan")[i].src=podatci.slika1;
                                niz_slika.push(podatci.slika1);
                            }
                            else if(i==1){
                                if(br_slika-i>0){
                                    document.getElementsByClassName("kolona jedan")[i].src=podatci.slika2;
                                    niz_slika.push(podatci.slika2);
                                }
                                else{
                                    document.getElementsByClassName("kolona jedan")[i].style.visibility='hidden';
                                }
                            }
                            else{
                                if(br_slika-i>0){
                                document.getElementsByClassName("kolona jedan")[i].src=podatci.slika3;
                                niz_slika.push(podatci.slika3);
                                }
                                else{
                                    document.getElementsByClassName("kolona jedan")[i].style.visibility='hidden';
                                }
                            }
                        }
            
                    }
                }
            }
            else if(slj ){
                br_poziva_pret++;
                for(var i=0;i<3;i++){
                    if(i==0){
                        document.getElementsByClassName("kolona jedan")[i].src=niz_slika[(br_poziva_pret-1)*3+i];
                    }
                    else if(i==1){
                        document.getElementsByClassName("kolona jedan")[i].src=niz_slika[(br_poziva_pret-1)*3+i];
                    }
                    else{
                        document.getElementsByClassName("kolona jedan")[i].src=niz_slika[(br_poziva_pret-1)*3+i];
                    }
                }
            }
        }
        else if(slj && br_poziva_pret!=br_poziva_slj){
            br_poziva_pret++;
            for(var i=0;i<3;i++){
                if(i==0){
                    document.getElementsByClassName("kolona jedan")[i].src=niz_slika[(br_poziva_pret-1)*3+i];
                }
                else if(i==1){
                    if((br_poziva_pret-1)*3+i<br_sl_uk){
                        document.getElementsByClassName("kolona jedan")[i].src=niz_slika[(br_poziva_pret-1)*3+i];
                    }
                    else{
                        document.getElementsByClassName("kolona jedan")[i].style.visibility='hidden';
                    }
                }
                else{
                    if((br_poziva_pret-1)*3+i<br_sl_uk){
                        document.getElementsByClassName("kolona jedan")[i].src=niz_slika[(br_poziva_pret-1)*3+i];
                    }
                    else{
                        document.getElementsByClassName("kolona jedan")[i].style.visibility='hidden';
                    }
                }
            }
        }
        
    });
}
    
    }
    return {
    prvi: prviImpl,
    drugi: drugiImpl,
    treci: treciImpl
    }
}());
//module.exports=Pozivi;