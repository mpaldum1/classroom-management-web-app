const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
app.use(bodyParser.json());

app.use(express.static(__dirname));

app.get('/rezervacija.html',function(req,res){
    res.sendFile(__dirname+"/rezervacija.html");
});
app.get('/ucitaj',function(req,res){
    res.sendFile(__dirname+"/zauzeca.json");
});
app.get('/',function(req,res){
    res.sendFile(__dirname+"/pocetna.html");
});
app.post('/upisiper',function(req,res){


        var greska=false;
        fs.readFile('zauzeca.json',(err,data) =>{
            if(err) throw err;
            let zz=JSON.parse(data);
            var niz_dat=zz['periodicna'];
            var mjs=req.query.mjesec;
            
            for(var i=0;i<niz_dat.length;i++){
                var sem= niz_dat[i].semestar;
                if((mjs>8 && mjs<12) || mjs==0){
                    if(sem=="ljetni")continue;
              
                    if(parseInt(req.query.dan)==niz_dat[i].dan && req.query.sala==niz_dat[i].naziv){
                        greska=true;
                        break;
                    }
                }
                else if(mjs>0 && mjs<6){
                    if(sem=="zimski")continue;
                    if(parseInt(req.query.dan)==niz_dat[i].dan && req.query.sala==niz_dat[i].naziv){
                        greska=true;
                        break;
                    }
                }
            }
            var niz_van=zz['vandredna'];
            for(var i=0;i<niz_van.length;i++){
                if((mjs>8 && mjs<12) || mjs==0){
                    
                    var dateString = niz_van[i].datum; // Oct 23

                    var dateParts = dateString.split(".");

                    var dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]); 

                    var god=+dateParts[2];
                    var mjesecc=dateParts[1] - 1;
                    var dann=+dateParts[0];
                    //ako je mjesec van zimskog semestra
                    if(mjesecc>0 && mjesecc<9)continue;

                    var firstDay =  new Date(dateObject.getFullYear(), mjesecc, 1); 
                    var s=firstDay.getDay();

                    var dd;
                    if(s===0){
                        s=6;
                        dd=(s-1)+parseInt(dann);
                    }else{
                        dd=(s-2)+parseInt(dann);
                    }
    
                    dd=dd%7;
                    if(dd==parseInt(req.query.dan) && niz_van[i].naziv==req.query.sala){
                        
                        greska=true;
                        
                        break;
                    }
                }
                else if(mjs>0 && mjs<6){
                    
                    var dateString = niz_van[i].datum; // Oct 23

                    var dateParts = dateString.split(".");

                    var dateObject = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0]); 

                    var god=+dateParts[2];
                    var mjesecc=dateParts[1] - 1;
                    var dann=+dateParts[0];

                    //ako je mjesec van ljetnog semestra
                    if((mjesecc>8 && mjesecc<12) || mjesecc==0)continue;
                    var firstDay =  new Date(dateObject.getFullYear(), mjesecc, 1); 
                    var s=firstDay.getDay();

                    var dd;
                    if(s===0){
                        s=6;
                        dd=(s-1)+parseInt(dann);
                    }else{
                        dd=(s-2)+parseInt(dann);
                    }
    
                    dd=dd%7;
                    if(dd==parseInt(req.query.dan)){
                        greska=true;
                    }
                }
            }
            if(req.query.mjesec>0 && req.query.mjesec<6){
                zz['periodicna'].push({"dan":parseInt(req.query.dan),"semestar":"ljetni","pocetak":req.query.pocetak,"kraj":req.query.kraj,"naziv":req.query.sala,"predavac":"novi"});

            }
            else if((req.query.mjesec>8 && req.query.mjesec<12) || req.query.mjesec==0){
                zz['periodicna'].push({"dan":parseInt(req.query.dan),"semestar":"zimski","pocetak":req.query.pocetak,"kraj":req.query.kraj,"naziv":req.query.sala,"predavac":"novi"});
            }
            
            if(greska==false){
                    fs.writeFile('zauzeca.json',JSON.stringify(zz),(err) =>{
                        if(err) throw err;
                        
                        res.sendFile(__dirname+"/zauzeca.json");
                    });
            
        }
        else{
            
            var godina=new Date();
            var mj=parseInt(req.query.mjesec)+1;
            res.send({"mesage":"Nije moguće rezervisati salu "+req.query.sala +" za navedeni datum "+req.query.datum+"/"+mj+"/"+godina.getFullYear()+" i termin od "+req.query.pocetak +" do " +req.query.kraj+"!"});
        }
        });
        
});
app.post('/upisivan',function(req,res){
    

        var godina=new Date();

        var greska=false;

        fs.readFile('zauzeca.json',(err,data) =>{
            if(err) throw err;
            let zz=JSON.parse(data);
            var mj=parseInt(req.query.mjesec)+1;
            var dat_dol=req.query.datum+"."+mj+"."+godina.getFullYear();
            var niz_van=zz['vandredna'];
            for(var i=0;i<niz_van.length;i++){
                if(niz_van[i].datum==dat_dol){
                    greska=true;
                }
            }
            zz['vandredna'].push({"datum":req.query.datum+"."+mj+"."+godina.getFullYear(),"pocetak":req.query.pocetak,"kraj":req.query.kraj,"naziv":req.query.sala,"predavac":"novi"});
            
            if(greska==false){
            fs.writeFile('zauzeca.json',JSON.stringify(zz),(err) =>{
                if(err) throw err;
                res.sendFile(__dirname+"/zauzeca.json");
            });
        }
        else{
            res.send({"mesage":"Nije moguće rezervisati salu "+req.query.sala +" za navedeni datum "+req.query.datum+"/"+mj+"/"+godina.getFullYear()+" i termin od "+req.query.pocetak +" do " +req.query.kraj+"!"});
        }
        });
        
        
});

app.get('/ucitajsl',function(req,res){
    if(req.query.br==1){
        res.json({slika1:"https://upload.wikimedia.org/wikipedia/commons/a/a5/20150331_2026_AUT_BIH_2177_Edin_D%C5%BEeko.jpg",slika2:"http://radiobet.eu/wp-content/uploads/2017/11/b_171111090.jpg",slika3:"https://storage.radiosarajevo.ba/image/448088/1180x732/BiH_Grcka_Bilino_2019_mart_RSA_DZ_K010.jpg"});
    }
    else if(req.query.br==2){
        res.json({slika1:"https://storage.radiosarajevo.ba/image/243045/1180x732/Zvjezdan_misimovic.jpg",slika2:"https://www.life.ba/wp-content/uploads/2013/12/aa_picture_20131226_1248251_high.jpg",slika3:"https://www.nfsbih.ba/images/2019-D/010_oktobar/dinko_-_gojak.jpg"});
    }
    else if(req.query.br==3){
        res.json({slika1:"https://www.dulist.hr/wp-content/uploads/2019/08/spahic.jpg",slika2:"https://www.inmedia.ba/wp-content/uploads/2017/06/sead.jpg",slika3:"https://storage.radiosarajevo.ba/image/315024/1180x732/Muhamed_Besic_1_RSA.jpg"});
    }
    else{
        res.json({slika1:"https://storage.bljesak.info/image/290861/1280x880/Edin-Visca.jpg"});

    }
});


app.listen(8080);