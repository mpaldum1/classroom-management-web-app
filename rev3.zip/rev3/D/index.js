let mapaPocetnihDana = new Map([[0,  1], [1,  4], [2,  4], [3,  0], [4,  2], [5,  5], [6,  0], [7, 3], [8,  6],[9,  1], [10,  4], [11,  6]]);
let mjesecSale;
let godina;
const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const fs = require('fs');

const app = express();
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(express.static('js'));
app.use(express.static('css'));
  
//za pocetnu
app.get("/pocetna.html", function (req, res) {
    res.sendFile(__dirname + "/pocetna.html");
});
app.get('/',function(req,res){
    res.sendFile(__dirname+"/pocetna.html");
 });
 
//za rezervaciju
app.get("/rezervacija.html", function (req, res) {
    res.sendFile(__dirname + "/rezervacija.html");
});
    
//za sale
app.get("/sale.html", function (req, res) {
    res.sendFile(__dirname + "/sale.html");
});
    
//za unos
app.get("/unos.html", function (req, res) {
    res.sendFile(__dirname + "/unos.html");
});
    
app.get("/index.js", function (req, res) {
    res.sendFile(__dirname + "/index.js");
});

app.get("/pozivi.js", function (req, res) {
    res.sendFile(__dirname + "/pozivi.js");
});

app.get("/zauzeca.json", function (req, res) {
    res.sendFile(__dirname + "/zauzeca.json");
});

app.get('/slike/logo.png', function (req, res) {
    res.sendFile(__dirname + '/slike/logo.png');
});

app.get('/pocetnaStrana', function (req, res) {
    for (let i = 1; i < 4; i++)
    {
        app.get('/slike/sala' + i +'.jpg', function (req, res) {
            res.sendFile(__dirname + '/slike/sala' + i +'.jpg');
        });
    }
    res.write("/slike/sala1.jpg,/slike/sala2.jpg,/slike/sala3.jpg");
    res.send();
});

app.get('/stranica2', function (req, res) {
    for (let i = 4; i < 7; i++)
    {
        app.get('/slike/sala' + i +'.jpg', function (req, res) {
            res.sendFile(__dirname + '/slike/sala' + i +'.jpg');
        });
    }
    res.write("/slike/sala4.jpg,/slike/sala5.jpg,/slike/sala6.jpg");
    res.send();
});

app.get('/stranica3', function (req, res) {
    for (let i = 7; i < 10; i++)
    {
        app.get('/slike/sala' + i +'.jpg', function (req, res) {
            res.sendFile(__dirname + '/slike/sala' + i +'.jpg');
        });
    }
    res.write("/slike/sala7.jpg,/slike/sala8.jpg,/slike/sala9.jpg");
    res.send();
});

app.get('/stranica4', function (req, res) {
    app.get('/slike/sala10.jpg', function (req, res) {
        res.sendFile(__dirname + '/slike/sala10.jpg');
    });
    res.write("/slike/sala10.jpg");
    res.send();
});

app.post('/zauzeca.json',function(req,res){
    let dodajSalu = false;
    fs.readFile('zauzeca.json', 'utf8' , (greska, data) => {
        if(greska) throw greska;
        let podaci = data.toString('utf-8');
        var contents = fs.readFileSync("zauzeca.json");
        var jsonContent = JSON.parse(contents);
        let periodicne = jsonContent.periodicna;
        let vanredne = jsonContent.vanredna;

        //Za periodicnu
        let pom1 = req.body['datum'].split(".");
        let danSaleKojaSeDodaje = pom1[0];
        mjesecSale = pom1[1];
        let pom2Mjesec = mjesecSale;
        mjesecSale--;
        mjesecSale = parseInt(mjesecSale);
        pom2Mjesec = parseInt(pom2Mjesec);
        godina = 2019;

        let semestarRezervacije = "";
        if(mjesecSale >=1 && mjesecSale <= 5) {
            semestarRezervacije = "ljetni";
        } else if(mjesecSale == 0 || (mjesecSale >= 9 && mjesecSale <= 11)) {
            semestarRezervacije = "zimski";
        }
        
        let noviDatum = pom2Mjesec + "." + danSaleKojaSeDodaje + "." + godina;
        let datumPomocna = new Date(noviDatum);
        let danSale = datumPomocna.getDay();
        danSale = dajDan(danSale);
        
        for (let i = 0; i < vanredne.length; i++)
        {
            //za validaciju vanredne i vanredne
            if (vanredne[i].naziv == req.body['naziv'] && vanredne[i].datum == req.body['datum'])
            {
                //koristim funkciju iz kalendara, ako se vrijeme ne poklapa dodamo 
                if (unutarVremena(req.body['pocetak'], req.body['kraj'], vanredne[i].pocetak, vanredne[i].kraj) == 1)
                {
                    dodajSalu = true;
                    break;
                    
                }
            }
            
            //prolazi kroz listu vanrednih i provjerava na koji su dan rezervisane
            if (req.body['periodicnaRezervacija'] == 1)
            {
                if (vanredne[i].naziv == req.body['naziv'])
                {
                    
                    let p1 = vanredne[i].datum.split(".");
                    let dan1 = p1[0];
                    let mjesec1 = p1[1];
                    mjesec1 = parseInt(mjesec1);
                    let godina1 = 2019;

                    let novi1 = mjesec1 + "." + dan1 + "." + godina1;
                    let novi1Pom = new Date(novi1);
                    let dan2 = novi1Pom.getDay();
                    dan2 = dajDan(dan2);

                    console.log("oooo" + mjesec1);
                    let semestarSaleIzListe = "";
                    if(mjesec1 >=2 && mjesec1 <= 6) {
                        semestarSaleIzListe = "ljetni";
                    } else if(mjesec1 == 1 || (mjesec1 >= 10 && mjesec1 <= 12)) {
                        semestarSaleIzListe = "zimski";
                    }
        
                    if (unutarVremena(req.body['pocetak'], req.body['kraj'], vanredne[i].pocetak, vanredne[i].kraj) == 1)
                    {
                        if (dan2 == danSale && semestarRezervacije == semestarSaleIzListe)
                        {
                            dodajSalu = true;
                            break;
                        } 
                    }
                }
            }
        }

        //Ako je periodicna i van semestara
        if (req.body['periodicnaRezervacija'] == 1)
        {
            if (semestarRezervacije == "")
            {
                dodajSalu = true;
            }    
        }

    
        for (let j = 0; j < periodicne.length; j++)
        {
            //provjera naziva sala
            if (periodicne[j].naziv == req.body['naziv'] && periodicne[j].semestar == semestarRezervacije)
            {
                    //provjera da li se vrijeme poklapa
                    if (unutarVremena(req.body['pocetak'], req.body['kraj'], periodicne[j].pocetak, periodicne[j].kraj) == 1)
                    {
                        //provjera da li su na isti dan unutar sedmice
                        if (danSale == periodicne[j].dan)
                        {
                            dodajSalu = true;
                            break;
                        }
                    }
            }
        }
         
        if (dodajSalu == false)
        {
            if (semestarRezervacije != "")
            {
                if (req.body['periodicnaRezervacija'] == 1)
                {
                    let pomocnaSala = { dan : danSale, semestar : semestarRezervacije, pocetak : req.body['pocetak'], kraj : req.body['kraj'],
                                    naziv : req.body['naziv'],  predavac : req.body['predavac']};
                    jsonContent.periodicna.push(pomocnaSala);
                }

                else
                {
                    let pomocnaSala = req.body;
                    delete pomocnaSala["periodicnaRezervacija"];
                    jsonContent.vanredna.push(pomocnaSala);
                }
            }

           else
            {
                let pomocnaSala = req.body;
                delete pomocnaSala["periodicnaRezervacija"];
                jsonContent.vanredna.push(pomocnaSala);
            }
            fs.writeFile("zauzeca.json", JSON.stringify(jsonContent),function(err, result) {
                if(err) console.log('error', err);
                jsonContent.ispravno = 1;
                res.json(jsonContent);
            });
        }
        else 
        {
            jsonContent.ispravno = 0;
            res.json(jsonContent);
        }

      }); 
 });
app.listen(8080);  

function unutarVremena(pocetak, kraj, salaPocetak, salaKraj)
{
    let zauzeta = 0;
    if (pocetak > salaPocetak && pocetak < salaKraj) 
         zauzeta = 1;
    else if (pocetak < salaPocetak && kraj > salaPocetak)
        zauzeta = 1;
    else if (pocetak == salaPocetak || kraj == salaKraj)
        zauzeta = 1;    
    return zauzeta;    
}

function dajDan(dan)
{
    if(dan == 0) 
        {
            dan = 6;
        } else {
            dan--;
        }

        return dan;
}