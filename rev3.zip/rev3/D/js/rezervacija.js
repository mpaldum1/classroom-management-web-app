function ucitajKalendar(){
    Pozivi.ucitajPodatke();
    let kalendar = document.getElementsByClassName("cal")[0];
    kalendar.innerHTML = "";
    Kalendar.iscrtajKalendar(kalendar, pomocnaMjesec);
    Kalendar.obojiZauzeca(document.getElementsByClassName("cal"), pomocnaMjesec, document.getElementsByClassName("saleIzbor")[0].value, 
                    document.getElementById("pocetak").value, document.getElementById("kraj").value);
}

function upisiZauzece(sala)
{
   Pozivi.upisiZauzeceServer(sala);
}


function osvjeziKalendar()
{
        let kalendar = document.getElementsByClassName("cal")[0];
        kalendar.innerHTML = "";
        Pozivi.ucitajPodatke();
        Kalendar.iscrtajKalendar(kalendar, pomocnaMjesec);
        Kalendar.ucitajPodatke(listaPeriodicnihSala, listaVanrednihSala);
        Kalendar.obojiZauzeca(document.getElementsByClassName("cal"), pomocnaMjesec, document.getElementsByClassName("saleIzbor")[0].value, 
                        document.getElementById("pocetak").value, document.getElementById("kraj").value);
}
