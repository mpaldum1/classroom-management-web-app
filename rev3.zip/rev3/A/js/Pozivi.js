var zauzeca;
var povrat;

function getZauzeca() {


    $.ajax({
        async: false,
        type: 'GET',
        url: 'http://localhost:8080/rezervacije',
        contentType: 'application/json',
        success: function (data) {
            zauzeca = data;
            console.log(zauzeca);
        }
        // error: function(XMLHttpRequest, textStatus, errorThrown) { 
        //     alert("Status: " + textStatus); alert("Error: " + errorThrown); 
        // }    
    });



    return zauzeca;
}

function postZauzece(rezervacija) {

    $.ajax({
        async: false,
        type: 'POST',
        url: 'http://localhost:8080/rezervacije',
        data: JSON.stringify(rezervacija),
        contentType: 'application/json',
        success: function (data) {
            console.log('Post Response: ', JSON.stringify(data, "", 2));
            // loadDoc();
            povrat = data;
        }
    })

    return povrat;
}


function getSlike() {
    //var imagesArray = [];
    $.ajax({
        url: 'http://localhost:8080/slike',
        success: function (data) {
            console.log(data);
            images = data;
        }


    })

    return images;
    
}