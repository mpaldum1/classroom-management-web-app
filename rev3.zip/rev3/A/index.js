const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');



app.use(express.static(__dirname));
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname + '/pocetna.html'));
})

app.get('/rezervacije', (req, res) => {

    fs.readFile('zauzeca.json', (err, data) => {

        console.log("Dohvatam....", JSON.parse(data));
        res.send(JSON.parse(data));
    });
})

app.get('/slike',(req, res) => {
  var img = Array();

	fs.readdir('./slike', function(err, files) {
		if (err) {
			console.log("Nema Foldera \n" + err);
			return;
		}

		files.forEach(function (file) {
			fs.readFile('./slike' + "/" + file, function(err, data) {
  			if (err) {
  				console.log("File se nije mogao ucitati. \n" + err);
  				throw err;
  			}
              img.push(data);
              if(img.length === 12) 
                    res.send(img);
          });
           
        });
       
    });
    

})

app.post('/rezervacije', (req, res) => {

    
    let rezervacija = req.body;
    // let zauzeca;
    fs.readFile('zauzeca.json', function (err, data) {
        let json = JSON.parse(data);

        //console.log("datehandler", dateHandler(rezervacija, json.periodicna));

        if (rezervacija.dan !== undefined)
        {
            json.periodicna.push(rezervacija);
            
        }
        else
        {
              json.vanredna.push(rezervacija);
        }
        //zauzeca = json;
        fs.writeFile("zauzeca.json", JSON.stringify(json), err => {
            if (err)
                console.log('Greska se desila');
            else
                console.log('Upisano u fajl');
        })

        res.send(json);
    })

    //    res.send(zauzeca)
});

app.listen(8080);
