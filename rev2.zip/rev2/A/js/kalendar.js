let Kalendar = (function(){
  var periodicnaZaduzenja = [];
  var vanrednaZaduzenja = [];

  function odrediZaduzenje(redovi,zauzetiRedovi,vanredniDani){
    for(var i=0; i<redovi.length; i++){
        var celije = redovi[i].getElementsByTagName('td');
        for(var j=0; j<celije.length; j++) {
            if((zauzetiRedovi.indexOf(j) != -1 || vanredniDani.indexOf(parseInt(celije[j].innerText)) != -1) && celije[j].classList.contains('tbDate')) {
                celije[j].classList.remove('slobodna');
                celije[j].classList.add('zauzeta');
            }
        }
    }
  }

  // Zadatak 2 iscrtajKalendar
  
  function iscrtajKalendar(kalendarRef, mjesec) {
    
    var year = new Date().getFullYear();

    mjesec += 1;

    let month = "";

    switch(mjesec) {
      case 1:
        month = 'Januar';
        break;
      case 2:
        month = 'Februar';
        break;
      case 3:
        month = 'Mart';
        break;
      case 4:
        month = 'April';
        break;
      case 5:
        month = 'Maj';
        break;
      case 6:
        month = 'Juni';
        break;
      case 7:
        month = 'Juli';
        break;
      case 8:
        month = 'August';
        break;
      case 9:
        month = 'Septembar';
        break;
      case 10:
        month = 'Oktobar';
        break;
      case 11:
        month = 'Novembar';
        break;
      case 12:
        month = 'Decembar';
        break;    
      default:
        month = "";
        break;
    }

    var prvi = new Date(year, mjesec-1, 1);
    var zadnji = new Date(year, mjesec, 0);
    var _prvi = prvi.toString();
    
    var daysLimit = zadnji.getDate();
    var firstDay = _prvi.substring(0, _prvi.indexOf(' '));

    // dan u sedmici kad pocinje mjesec
    var daysOffset = 0;

    switch(firstDay) {
      case "Mon":
          daysOffset = 0;
          break;
      case "Tue":
          daysOffset = 1;
          break;
      case "Wed":
          daysOffset = 2;
          break;
      case "Thu":
          daysOffset = 3;
          break;
      case "Fri":
          daysOffset = 4;
          break;
      case "Sat":
          daysOffset = 5;
          break;
      case "Sun":
          daysOffset = 6;
          break;
      default:
          daysOffset = -1;
          break;
    }

    var weeks = Math.ceil((daysOffset + prvi.getDay() + zadnji.getDate())/7);
    
    var kalendarHtml = '<table class="tabelaKalendar"><tr><th colspan=7>';
    kalendarHtml += month;
    kalendarHtml += '</th></tr><tr><th>PON</th><th>UTO</th><th>SRI</th><th>CET</th><th>PET</th><th>SUB</th><th>NED</th></tr>';
    for(var i=0; i<weeks; i++) {
        //red tebele / sedmica
        kalendarHtml += '<tr>'
        for(var j=0; j<7; j++) {
            // ispisivanje celije
            var ddd = (i*7 + (j + 1)) - daysOffset;
            if (ddd > 0 && ddd <= daysLimit){
              kalendarHtml +=  '<td class="tbDate slobodna">' + ddd + '<div></div></td>';
            }
            else{
              kalendarHtml += '<td class="noDate"></td>';
            }
        }
        kalendarHtml += '</tr>';
    }
    kalendarHtml += '</table>';
    kalendarHtml += '<div class="bottomSection"><button class="prethodni" id="prethodni">Prethodni</button><button class="slijedeci" id="slijedeci">Slijedeci</button></div>';
    
    kalendarRef.innerHTML = kalendarHtml;

    let prethodni = document.getElementById('prethodni');
    let slijedeci = document.getElementById('slijedeci');
  
    if(prethodni){
      prethodni.addEventListener('click', klikPrethodni);
    }
    if(slijedeci){
      slijedeci.addEventListener('click', klikSlijedeci);
    }

    function klikPrethodni() {
      if(mjesec == 1)
          return;
      Kalendar.iscrtajKalendar(kalendarRef, mjesec - 2);
    }
  
    function klikSlijedeci() {            
      if(mjesec == 12)
          return;
      Kalendar.iscrtajKalendar(kalendarRef, mjesec);
    }
  }

  // Zadatak 1

  function obojiZauzeca(kalendarRef, mjesec, sala, pocetak, kraj) {

      iscrtajKalendar(kalendarRef, mjesec);

      if(periodicnaZaduzenja.length == 0 && vanrednaZaduzenja.length == 0){
        return;
      }

      var trenutniSemestar = "";

      if(mjesec == 9 || mjesec == 10 || mjesec == 11 || mjesec == 0){
        trenutniSemestar = "zimski";
      }
      else if(mjesec == 1 || mjesec == 2 || mjesec == 3 || mjesec == 4 || mjesec == 5){
        trenutniSemestar = "ljetni";
      }
      else{
        trenutniSemestar = "";
      }
      
      if(trenutniSemestar === "")
          return;

      var periodicna = periodicnaZaduzenja.filter(x => x.semestar == trenutniSemestar);

      periodicna = periodicna.filter(x => {
          return !(Date.parse('01/01/2011 ' + x.pocetak + ':00') >= Date.parse('01/01/2011 ' + kraj + ':00') &&
                  Date.parse('01/01/2011 ' + x.kraj + ':00') >= Date.parse('01/01/2011 ' + pocetak + ':00'));
      });

      var zauzetiRedovi = periodicna.map(x => x.dan);

      var vanredna = vanrednaZaduzenja.filter(x => {
          var firstIndex = x.datum.indexOf('.');
          var secondIndex = x.datum.indexOf('.', firstIndex + 1);
          
          return parseInt(x.datum.substring(firstIndex + 1, secondIndex)) == (mjesec + 1);
      });
      
      vanredna = vanredna.filter(x => {
          return !(Date.parse('01/01/2011 ' + x.pocetak + ':00') >= Date.parse('01/01/2011 ' + kraj + ':00') &&
                  Date.parse('01/01/2011 ' + x.kraj + ':00') >= Date.parse('01/01/2011 ' + pocetak + ':00'));
      });
      
      var vanredniDani = vanredna.map(x => parseInt(x.datum.substring(0, x.datum.indexOf('.'))));

      var redovi = kalendarRef.getElementsByTagName('tbody')[0].getElementsByTagName('tr')

      odrediZaduzenje(redovi,zauzetiRedovi,vanredniDani);

  }

  function ucitajPodatke(periodicna, vanredna) {
      if (periodicna){
        periodicnaZaduzenja = periodicna;
      }
      else{
        periodicnaZaduzenja = [];
      }

      if (vanredna){
        vanrednaZaduzenja = vanredna;
      }
      else{
        vanrednaZaduzenja = [];
      }
  }

  return {
      obojiZauzeca: obojiZauzeca,
      ucitajPodatke: ucitajPodatke,
      iscrtajKalendar: iscrtajKalendar
  }
}());