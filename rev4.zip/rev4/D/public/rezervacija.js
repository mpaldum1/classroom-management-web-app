window.onload= function (){
    Pozivi.rezervisi();
    //Pozivi.otvoriRezervacije();
    Pozivi.select();
};

