window.onload= function (){
    Pozivi.osoblje();
};

