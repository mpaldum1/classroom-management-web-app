const Sequelize = require("sequelize");
const sequelize = require("./db.js");
 
module.exports = function (sequelize, DataTypes) {
    const Osoblje = sequelize.define('Osoblje', {
       ime: Sequelize.STRING,
       prezime: Sequelize.STRING,
       uloga: Sequelize.STRING/*{
        type: Sequelize.STRING,
        validate: {
                is: ["[a-z]", 'i'],
           isIn: {
               args: [
                   ['profesor', 'asistent']
               ],
                msg: "Nije validna uloga."
            }
       }
    }*/
   });
   return Osoblje;
}
