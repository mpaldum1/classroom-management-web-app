const Sequelize = require("sequelize");
const sequelize = require("./db.js");
 
module.exports = function (sequelize, DataTypes) {
    const Rezervacija = sequelize.define('Rezervacija', {
        //termin: Sequelize.INTEGER,
        //sala: Sequelize.INTEGER,
        //osoba: Sequelize.INTEGER
    });
   return Rezervacija;
}