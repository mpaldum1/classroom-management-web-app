Pozivi.listaOsoblja();
setInterval(Pozivi.listaOsoblja, 30000);


function kreirajTabelu(podaci) {
    let forma = document.getElementById("pozicijaTabele");
    forma.innerHTML = podaci;
}