const Sequelize = require('sequelize');

module.exports = function(sequelize, DataTypes) {
    const Sala = sequelize.define("sala", {  // Sala{id,naziv:string,zaduzenaOsoba:integer FK}
        naziv: {
            type: Sequelize.STRING
        },
        zaduzenaOsoba: {
            type: Sequelize.INTEGER
        }
    }, {
        timestamps: false,
        freezeTableName: true
    });
    return Sala;
};