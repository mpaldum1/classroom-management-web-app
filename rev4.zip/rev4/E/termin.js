const Sequelize = require('sequelize');

module.exports = function(sequelize, DataTypes) {
    const Termin = sequelize.define("termin", {  // Termin{id,redovni:boolean, dan:integer, datum:string, 
                                                //  semestar:integer, pocetak:time, kraj:time}
        redovni: {
            type: Sequelize.BOOLEAN
        },
        dan: {
            type: Sequelize.INTEGER
        },
        datum: {
            type: Sequelize.STRING
        },
        semestar: {
            type: Sequelize.STRING
        },
        pocetak: {
            type: Sequelize.TIME
        },
        kraj: {
            type: Sequelize.TIME
        }
    }, {
        timestamps: false,
        freezeTableName: true
    });
    return Termin;
};