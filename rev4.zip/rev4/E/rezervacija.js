const Sequelize = require('sequelize');

module.exports = function(sequelize, DataTypes) {
    const Rezervacija = sequelize.define("rezervacija", {  // Rezervacija{id,termin:integer FK UNIQUE,sala:integer FK,osoba:integer FK}
        termin: {
            type: Sequelize.INTEGER,
            unique: true
        },
        sala: {
            type: Sequelize.INTEGER
        },
        osoba: {
            type: Sequelize.INTEGER
        }
    }, {
        timestamps: false,
        freezeTableName: true
    });
    return Rezervacija;
};