const Sequelize = require('sequelize');
/*
const connection = new Sequelize("DBWT19", "root", "root", {
     dialect: "mysql",
     logging: false
 });
*/
const connection = new Sequelize("DBWT19", "root", "root", {
    dialect: 'mysql',
    //host: 'DBWT19.db',
    logging: false
});

const db = {};

db.Sequelize = Sequelize;
db.connection = connection;

db.osoblje = connection.import(__dirname+'/osoblje.js');
db.rezervacija = connection.import(__dirname+'/rezervacija.js');
db.termin = connection.import(__dirname+'/termin.js');
db.sala = connection.import(__dirname+'/sala.js');

db.osoblje.hasMany(db.rezervacija, {foreignKey: 'osoba'});
db.termin.hasOne(db.rezervacija, { foreignKey: 'termin' });
db.sala.hasMany(db.rezervacija, {foreignKey: 'sala'});
db.osoblje.hasOne(db.sala, {foreignKey: 'zaduzenaOsoba'});

db.connection.sync({force:true}) //, logging: console.log
    .then(async function(){
            await db.osoblje.bulkCreate([ 
                {
                    ime: 'Neko',
                    prezime: 'Nekić',
                    uloga: 'profesor'
                },
                {
                    ime: 'Drugi',
                    prezime: 'Neko',
                    uloga: 'asistent'
                },
                {
                    ime: 'Test',
                    prezime: 'Test',
                    uloga: 'asistent'
                }
            ])
        .then(async function() {
                await db.termin.bulkCreate([ 
                    {
                        redovni: false,
                        dan: null,
                        datum: '01.01.2020',
                        semestar: null,
                        pocetak: '12:00',
                        kraj: '13:00'
                    },
                    {
                        redovni: true,
                        dan: 0,
                        datum: null,
                        semestar: 'zimski',
                        pocetak: '13:00',
                        kraj: '14:00'
                    }
                ])
            .then(async function() {
                await db.sala.bulkCreate([ 
                    {
                        naziv: '1-11',
                        zaduzenaOsoba: '1'
                    },
                    {
                        naziv: '1-15',
                        zaduzenaOsoba: '2'
                    }
                ])

                . then(async function(){
                    await db.rezervacija.bulkCreate([ 
                        {
                            termin: 1,
                            sala: 1,
                            osoba: 1
                        },
                        {
                            termin: 2,
                            sala: 1,
                            osoba: 3
                        }
                    ]);
                });
            });
        });
    }).then(function(){
        console.log("OK!");
    });
    


module.exports=db;
