const express = require('express');
const bodyParser = require('body-parser');
const moment = require('moment');
const fs = require('fs');
const PORT = 8080;
const app = express();
const userAgent = require('useragent');
const IP = require('ip');
const folderSlike = './public/slike/';
const db = require('./db');
const { QueryTypes } = require('sequelize');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/public'));

app.get('/', function(req, res) {
	res.sendFile('./public/pocetna.html', { root: __dirname });
});

async function vratiRezervacijeIzBaze(){
	var upit = "SELECT o.ime, o.prezime, t.dan, t.datum, t.semestar, t.pocetak, t.kraj, s.naziv FROM `rezervacija` as r, `sala` as s, `termin` as t,`osoblje` as o WHERE r.termin=t.id AND r.sala = s.id AND r.osoba = o.id";
	const rezervacije_raw = await db.connection.query(upit, { type: QueryTypes.SELECT });
	
	var rezervacije = {
		periodicniPodaci:[],
		vanredniPodaci:[]
	}
	for(var i = 0; i < rezervacije_raw.length; i++){
		rezervacije_raw[i].predavac = rezervacije_raw[i].ime + ' ' + rezervacije_raw[i].prezime;
		rezervacije_raw[i].pocetak = rezervacije_raw[i].pocetak.substring(0, 5);					// jer MySql uzima format vremena kao hh:mm:ss,
		rezervacije_raw[i].kraj = rezervacije_raw[i].kraj.substring(0, 5);							// a mi saljemo hh:mm pa pri provjeri nikad ne bi bilo tacno
		delete rezervacije_raw[i].ime;
		delete rezervacije_raw[i].prezime;				// Jer smo ih stavili u .predavac
		if(rezervacije_raw[i].dan !== null){
			delete rezervacije_raw[i].datum              // Ako su periodicna zauzeca ne treba nam datum
			rezervacije.periodicniPodaci.push(rezervacije_raw[i]);
		}
		else{
			delete rezervacije_raw[i].dan
			delete rezervacije_raw[i].semestar           // Ako su vanredna ne trebaju nam dan i semestar
			rezervacije.vanredniPodaci.push(rezervacije_raw[i]);
		}
	}
	return rezervacije;
}

app.get('/api', async function(req, res) {
	var rezervacije = await vratiRezervacijeIzBaze();
	res.send(rezervacije);
});

function daLiJePeriodicniTerminRezervisan(periodicna, dan, semestar, pocetak, kraj, sala) {
	for (let i = 0; i < periodicna.length; i++) {
		if (
			periodicna[i].semestar === semestar &&
			periodicna[i].naziv === sala &&
			periodicna[i].pocetak === pocetak &&
			periodicna[i].kraj === kraj &&
			periodicna[i].dan === dan 
			) {
			return true;
		}
	}
	return false;
}
function daLiJeVanredniTerminRezervisan(vanredna, datum, pocetak, kraj, sala) {
	for (let i = 0; i < vanredna.length; i++) {
		if (
			vanredna[i].datum === datum &&
			vanredna[i].naziv === sala &&
			vanredna[i].pocetak === pocetak &&
			vanredna[i].kraj === kraj 
			) {
			return true;
		}
	}
	return false;
}

app.post('/rezervacije', async function(req, res) {
	var rezervacije = await vratiRezervacijeIzBaze();
	let rezervacija = req.body;	

	if (rezervacija.hasOwnProperty('datum')) {
		if (
			daLiJeVanredniTerminRezervisan(
				rezervacije.vanredniPodaci,
				rezervacija['datum'],
				rezervacija['pocetak'],
				rezervacija['kraj'],
				rezervacija['naziv']			)
		) {
			let formatiranDatum = moment(rezervacija['datum'], 'DD.MM.YYYY').format('DD/MM/YYYY');
			res.send({
				message:
					'Nije moguće rezervisati salu ' +
					rezervacija['naziv'] +
					' za navedeni datum ' +
					formatiranDatum +
					' i termin od ' +
					rezervacija['pocetak'] +
					' do ' +
					rezervacija['kraj'] + ' jer je prije Vas rezervisao ' + rezervacija['predavac'] +
					'!'
			});
		} else {
			var [ime,prezime,uloga] = rezervacija.predavac.split(' ')
			uloga = uloga.slice(1,uloga.length-1);
			
			var osobaId,salaId,terminId;

			await db.osoblje.findOrCreate({where:{ime:ime,prezime:prezime,uloga:uloga}}).then(function(osoba){
				osobaId = osoba[0].id;
			}).catch(error=>console.log("ERROR",error))

			await db.sala.findOrCreate({where:{naziv:rezervacija.naziv, zaduzenaOsoba: osobaId}}).then(function(sala){
				salaId = sala[0].id;
			}).catch(error=>console.log("ERROR",error))

			await db.termin.findOrCreate({where:{redovni:0,dan:null,datum:rezervacija.datum,semestar:null,pocetak:rezervacija.pocetak,kraj:rezervacija.kraj}}).then(function(termin){
				terminId = termin[0].id;
			}).catch(error=>console.log("ERROR",error))

			await db.rezervacija.create(
				{
					termin: terminId,
					sala: salaId,
					osoba: osobaId
				}
			).then(function(rez){
			}).catch(error=>console.log("ERROR",error))
			rezervacije.vanredniPodaci.push(rezervacija);
		}
	} else {
		if (
			daLiJePeriodicniTerminRezervisan(
				rezervacije.periodicniPodaci,
				rezervacija['dan'],
				rezervacija['semestar'],
				rezervacija['pocetak'],
				rezervacija['kraj'],
				rezervacija['naziv']
			)
		) {
			var upit1 = "SELECT o.ime, o.prezime, o.uloga, s.naziv FROM `sala` as s, `termin` as t,`osoblje` as o WHERE s.zaduzenaOsoba = o.id AND s.naziv = ?";
			const ime_prezime_uloga = await db.connection.query(upit1, { 
				replacements: [rezervacija['naziv']],
				type: QueryTypes.SELECT 
			});

			res.send({
				message:
					'Nije moguće rezervisati salu ' +
					rezervacija['naziv'] +
					' za navedeni datum' +
					' i termin od ' +
					rezervacija['pocetak'] +
					' do ' +
					rezervacija['kraj'] + ' jer je rezervisana od strane ' 
					+ ime_prezime_uloga[0].ime + ' ' + ime_prezime_uloga[0].prezime 
					+ ' (' + ime_prezime_uloga[0].uloga + ') !'
			});
		} else {
			var [ime,prezime,uloga] = rezervacija.predavac.split(' ');
			uloga = uloga.slice(1,uloga.length-1);

			var osobaId,salaId,terminId;
			await db.osoblje.findOrCreate({where:{ime:ime,prezime:prezime,uloga:uloga}}).then(function(osoba){
				osobaId = osoba[0].id;
			}).catch(error=>console.log(error))

			await db.sala.findOrCreate({where:{naziv:rezervacija.naziv, zaduzenaOsoba: osobaId}}).then(function(sala){
				salaId = sala[0].id;
			}).catch(error=>console.log(error))

			await db.termin.create({redovni:1,dan:rezervacija.dan,datum:null,semestar:rezervacija.semestar,pocetak:rezervacija.pocetak,kraj:rezervacija.kraj}).then(function(termin){
				terminId = termin.id;
			}).catch(error=>console.log(error))

			await db.rezervacija.create(
				{
					termin: terminId,
					sala: salaId,
					osoba: osobaId
				}
			).then(function(rez){
			}).catch(error=>console.log("ERROR:",error))
			rezervacije.periodicniPodaci.push(rezervacija);
		}
	}
	res.send(rezervacije);
});

app.get('/slike/', function(req, res) {
	var brojac = 0;
	var path = './slike/';
	var slike = [];

	fs.readdir(folderSlike, (err, files) => {
		files.forEach((element) => brojac++);
		for (var i = 0; i < brojac; i++) {
			slike.push(path + files[i]);
		}
	});

	setTimeout(function() {
		res.send({
			slike: slike,
			brojStranica: Math.ceil(slike.length / 3)
		});
	}, 500);
});

app.get('/stats', function(req, res) {
	var usersIP = IP.address();
	let rawdata = fs.readFileSync('./stats.json');
	res.header('Content-Type', 'application/json');
	let stats = JSON.parse(rawdata);
	var browser = userAgent.parse(req.headers['user-agent']);
	if (browser.family == 'Firefox') {
		stats.firefox = stats.firefox + 1;
	}
	if (browser.family == 'Chrome') {
		stats.chrome = stats.chrome + 1;
	}
	if (!stats.ip_addresses.includes(usersIP)) {
		stats.ip_addresses_count = stats.ip_addresses_count + 1;
		stats.ip_addresses.push(usersIP);
	}

	fs.writeFileSync('./stats.json', JSON.stringify(stats));
	res.send(stats);
});

app.get('/osoblje', async function(req, res) {
	await db.osoblje.findAll()
	.then((osoblje) => {
		res.send(JSON.stringify(osoblje));
	});
});

async function vratiOsobuUKancelariji() {
	var upit = "SELECT o.ime, o.prezime FROM `osoblje` as o WHERE o.id NOT IN (SELECT r.osoba FROM `rezervacija` as r) AND o.id NOT IN(SELECT o.id FROM `sala` as s, `termin` as t,`osoblje` as o, `rezervacija` as r  WHERE r.osoba = o.id AND t.id = r.termin AND r.sala = s.id)";
	const rezervacije_raw = await db.connection.query(upit, { type: QueryTypes.SELECT });

	var rezervacije = [];
	for (var i = 0; i < rezervacije_raw.length; i++) {	
		rezervacije.push(rezervacije_raw[i]);
	}
	return rezervacije;
}

async function vratiZaduzeneOsobe() {
	var upit = "SELECT o.ime, o.prezime, s.naziv, t.dan, t.datum, t.pocetak, t.kraj FROM `sala` as s, `termin` as t,`osoblje` as o, `rezervacija` as r WHERE r.sala = s.id AND r.osoba = o.id AND t.id = r.termin";
	const rezervacije_raw = await db.connection.query(upit, { type: QueryTypes.SELECT });

	var rezervacije = [];
	for (var i = 0; i < rezervacije_raw.length; i++) {
		rezervacije.push(rezervacije_raw[i])
	}
	return rezervacije;
}

app.get('/osobljeSaSalom', async function(req, res) {
	var rezervacijeUKancelariji = await vratiOsobuUKancelariji();
	var rezervacijeZaduzenih = await vratiZaduzeneOsobe();
	var sveRezervacije = { postojiSala : [rezervacijeZaduzenih], uKancelariji : [rezervacijeUKancelariji] };
	res.send(sveRezervacije);
});

app.listen(PORT, () => {
	console.log('Listening on http://localhost:' + PORT + '/ port!');
});
