import Pozivi from './pozivi.js'

let Osobe = (function () {
	var postoji = [];
	var kancelarija = [];

	function kreirajTabelu(posjeduje, nePosjeduje) {
	  	var imenaKolona = ["Ime osobe", "Trenutna sala"];
	  	var divTable = document.getElementById('ispisOsoba');
	  	var table = document.createElement('table');
	  	table.classList.add('tabela');
	  	table.setAttribute('border', '1');    // Unutrasnji border

	  	var thead = document.createElement('thead');     // Kreiranje header-a
	  	thead.classList.add('headerIme');
	  	for (var i = 0; i < 2; i++) {
		  	thead.appendChild(document.createElement("th")).
		    appendChild(document.createTextNode(imenaKolona[i])); 
	  	}

	  	var tbdy = document.createElement('tbody');
	  	var danas = new Date();
	  	var year, month, day, zauzece;
		for (var i = 0; i < postoji[0].length; i++) {	
		    var tr = document.createElement('tr');
		   	var cell1 = tr.insertCell(0);
			var cell2 = tr.insertCell(1);
			if(postoji[0][i].dan == null) { 	//Vanredno zauzece nema dana
				year = parseInt(postoji[0][i].datum.split('.')[2]);
				month = parseInt(postoji[0][i].datum.split('.')[1]) - 1;
				day = parseInt(postoji[0][i].datum.split('.')[0]);
				zauzece = new Date(year, month, day);
			}
	  		//Ukoliko se podudara vrijeme onda stavi ime sale koja je zauzeta 
			if(parseInt(postoji[0][i].pocetak) <= danas.getHours() && parseInt(postoji[0][i].kraj) >= danas.getHours()){
		  		if(postoji[0][i].dan == (danas.getDay() + 1) % 7 || (zauzece.getDay() == danas.getDay() && zauzece.getMonth() == danas.getMonth() && zauzece.getFullYear() == danas.getFullYear())) {
		  			cell1.innerHTML = postoji[0][i].ime + ' ' + postoji[0][i].prezime;
				    cell2.innerHTML = postoji[0][i].naziv;
				    
				    tr.appendChild(cell1);
				    tr.appendChild(cell2);
				    
				    tbdy.appendChild(tr);
		  		}
	  		} else {//u suprotnom neka bude u kancelariji
	  			cell1.innerHTML = postoji[0][i].ime + ' ' + postoji[0][i].prezime;
			    cell2.innerHTML = 'U kancelariji';
			    
			    tr.appendChild(cell1);
			    tr.appendChild(cell2);
			    
			    tbdy.appendChild(tr);
	  		}
	  	
	  	}
	  	/*
		    //var td = document.createElement('td'); 
		    //td.appendChild(document.createTextNode(postoji[0][i].ime + ' ' + postoji[0][i].prezime));  
		    cell1.innerHTML = postoji[0][i].ime + ' ' + postoji[0][i].prezime;
		    cell2.innerHTML = postoji[0][i].naziv;
		    
		    tr.appendChild(cell1);
		    tr.appendChild(cell2);
		    
		    tbdy.appendChild(tr);
		}*/
	    for (var j = 0; j < kancelarija[0].length; j++) {
    		var trK = document.createElement('tr');
	    	var cellK1 = tr.insertCell(0);
			var cellK2 = tr.insertCell(1);
			cellK1.innerHTML = kancelarija[0][j].ime + ' ' + kancelarija[0][j].prezime;
    		cellK2.innerHTML = "U kancelariji";
    		trK.appendChild(cellK1);
	    	trK.appendChild(cellK2);

    		tbdy.appendChild(trK);
    	} 		    

	  table.appendChild(tbdy);
	  table.appendChild(thead);

	  divTable.appendChild(table);
	}

	function ucitajPodatke(postojiSala, uKancelariji) {
		postoji = [];
		kancelarija = [];

		for (var i = 0; i < postojiSala.length; i++) {
			postoji.push(postojiSala[i]);
		}
		for (var i = 0; i < uKancelariji.length; i++) {
			kancelarija.push(uKancelariji[i]);
		}

	}

	return {
		kreirajTabelu: kreirajTabelu,
		ucitajPodatke: ucitajPodatke
	};
}) ();

Pozivi.dajSaleNakon30sec(function(rezultat) {
	Osobe.ucitajPodatke(rezultat.postojiSala, rezultat.uKancelariji);
	Osobe.kreirajTabelu(rezultat.postojiSala, rezultat.uKancelariji);
});