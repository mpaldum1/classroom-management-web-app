var chai = require('chai');
var expect = chai.expect;
var assert = chai.assert;
//let chaiHttp = require('chai-http');
var request = require('request');
let should = chai.should();
let index = require('../index');
const db = require('../db');


//chai.use(chaiHttp);


describe('Test /osoblje', function() {
    it('Prvo ime treba biti "Neko": ', function (done) {
        try {
            request('http://localhost:8080/osoblje', function (error, response, body) {
                let osoblje = JSON.parse(body);
                assert.equal("Neko", osoblje[0].ime);
                done();
            });
        }
        catch (error) {
            done(error);
        }
    });
    it('Treba vratiti 3 osobe: ', function (done) {
        try {
            request('http://localhost:8080/osoblje', function (error, response, body) {
                let osoblje = JSON.parse(body);
                expect(osoblje).to.have.lengthOf(3);
                done();
            });
        }
        catch (error) {
            done(error);
        }
    });
});

describe('Test /rezervacije', function() {
    it('Prvo ime treba biti "Neko": ', function (done) {
        try {
            request('http://localhost:8080/api', function (error, response, body) {
                const users = await db.find({type: 'User'});
                //let rezervacije = JSON.parse(rezervacije);
                //console.log(rezervacije);
                done();
            });
        }
        catch (error) {
            done(error);
        }
    });
    /*it('Treba vratiti 3 osobe: ', function (done) {
        try {
            request('http://localhost:8080/api', function (error, response, body) {
                let osoblje = JSON.parse(body);
                expect(osoblje).to.have.lengthOf(3);
                done();
            });
        }
        catch (error) {
            done(error);
        }
    });*/
});


/*

describe('Kalendar', function() {
    describe('iscrtajKalendar()', function() {
        it('Test 1: Broj dana u Septembru : ', function() {
            Kalendar.iscrtajKalendar(null,8);
            let dan = document.getElementsByClassName("datum");
            let dani = [];
            for (let i = 0; i < dan.length; i++) {
                if(dan[i].innerHTML != "") dani.push(dan[i].innerHTML);
            }
            assert.equal(dani[dani.length-1], 30, "Dan treba biti 30");
        });
        it('Test 2: Broj dana u Decembru : ', function() {
            Kalendar.iscrtajKalendar(null,11);
            let dan = document.getElementsByClassName("datum");
            let dani = [];
            for (let i = 0; i < dan.length; i++) {
                if(dan[i].innerHTML != "") dani.push(dan[i].innerHTML);
            }
            assert.equal(dani[dani.length-1], 31, "Dan treba biti 31");
        });
        it('Test 3: Prvi dan u Novembru : ', function() {
            Kalendar.iscrtajKalendar(null,10);
            let dan = document.getElementsByClassName("datum");
            let i = 0;
            while (dan[i].innerHTML == "") i++;
            assert.equal(dan[i].classList.contains("pet"), true, "Novembar pocinje u Petak");
        });
        it('Test 4: Zadnji dan u Novembru : ', function() {
            Kalendar.iscrtajKalendar(null,10);
            let dan = document.getElementsByClassName("datum");
            let i = dan.length-1;
            while (dan[i].innerHTML == "") i--;
            assert.equal(dan[i].classList.contains("sub"), true, "Novembar zavrsava u Subotu");
        });
        */